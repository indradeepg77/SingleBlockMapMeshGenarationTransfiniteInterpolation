/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

#pragma once

#include <memory>
#include <vector>
#include <algorithm>
#include <assert.h>

using namespace std;

constexpr double PointTolerance = 1.0e-4;

struct HalfEdge
{
public:
    int sourceNodeIndex, targetNodeIndex;
    int adjTriangleIndex = -1;
    shared_ptr<HalfEdge> nextEdge = nullptr;
    shared_ptr<HalfEdge> twinEdge = nullptr;

    HalfEdge(int index1, int index2)
        : sourceNodeIndex(index1)
        , targetNodeIndex(index2)
    {
    }
    bool operator<(const HalfEdge& otherEdge);
    bool operator==(const HalfEdge& otherEdge);
    bool IsTwinEdge(const HalfEdge& otherEdge);
};

using HalfEdgeShared = shared_ptr<HalfEdge>;
using FaceSideEdge = vector<HalfEdgeShared>;

class Point
{
public:
    Point()
        : coordX(0.0)
        , coordY(0.0)
        , coordZ(0.0)
    {
    }
    Point(double x, double y, double z)
        : coordX(x)
        , coordY(y)
        , coordZ(z)
    {
    }
    Point(const Point& pt)
        : coordX(pt.coordX)
        , coordY(pt.coordY)
        , coordZ(pt.coordZ)
    {
    }

    double& operator[](int index)
    {
        assert(index >= 0 && index < 3);

        if (index == 0) return coordX;
        if (index == 1) return coordY;
        return coordZ;
    }

    bool operator==(const Point& otherPt) const
    {
        return fabs(
            (coordX - otherPt.GetXCoord()) < PointTolerance && fabs(coordY - otherPt.GetYCoord()) < PointTolerance &&
            fabs(coordZ - otherPt.GetZCoord()) < PointTolerance);
    }

    bool operator<(const Point& otherPt) const
    {
        if ((coordX - otherPt.GetXCoord()) < -PointTolerance) return true;
        if ((coordY - otherPt.GetYCoord()) < -PointTolerance) return true;
        if ((coordZ - otherPt.GetZCoord()) < -PointTolerance) return true;
        return false;
    }

    Point& operator+=(const Point& otherPt)
    {
        coordX += otherPt.GetXCoord();
        coordY += otherPt.GetYCoord();
        coordZ += otherPt.GetZCoord();
        return *this;
    }

    Point operator+(const Point& otherPt) const
    {
        return Point(coordX + otherPt.GetXCoord(), coordY + otherPt.GetYCoord(), coordZ + otherPt.GetZCoord());
    }

    Point operator-(const Point& otherPt) const
    {
        return Point(coordX - otherPt.GetXCoord(), coordY - otherPt.GetYCoord(), coordZ - otherPt.GetZCoord());
    }

    Point operator*(double value) const { return Point(coordX * value, coordY * value, coordZ * value); }

    Point operator/(double value) const
    {
        assert(value > 1e-8);
        return Point(coordX / value, coordY / value, coordZ / value);
    }

    Point& operator/=(double value)
    {
        assert(value > 1e-8);
        coordX /= value;
        coordY /= value;
        coordZ /= value;
        return *this;
    }

    static Point AveragePoints(const Point& pt1, const Point& pt2)
    {
        return Point(
            ((pt1.GetXCoord() + pt2.GetXCoord()) * 0.5), ((pt1.GetYCoord() + pt2.GetYCoord()) * 0.5),
            ((pt1.GetZCoord() + pt2.GetZCoord()) * 0.5));
    }

    static Point WightedAveragePoints(const Point& pt1, const Point& pt2, double weight)
    {
        double compWeight = 1.0 - weight;
        return Point(
            (pt1.GetXCoord() * weight + pt2.GetXCoord() * compWeight),
            (pt1.GetYCoord() * weight + pt2.GetYCoord() * compWeight),
            (pt1.GetZCoord() * weight + pt2.GetZCoord() * compWeight));
    }

    double GetXCoord() const { return coordX; }
    double GetYCoord() const { return coordY; }
    double GetZCoord() const { return coordZ; }

private:
    double coordX, coordY, coordZ;
};

class Triangle
{
public:
    Triangle(int index, int v1, int v2, int v3)
        : m_index(index)
        , m_ptIndex1(v1)
        , m_ptIndex2(v2)
        , m_ptIndex3(v3)
    {
    }

    int GetPointIndex(int index) const
    {
        assert(index >= 0 && index < 3);

        if (index == 0) return m_ptIndex1;
        if (index == 1) return m_ptIndex2;

        return m_ptIndex3;
    }

    Triangle& operator=(const Triangle& tria)
    {
        if (this == &tria) return *this;
        m_ptIndex1 = tria.m_ptIndex1;
        m_ptIndex2 = tria.m_ptIndex2;
        m_ptIndex3 = tria.m_ptIndex3;
        return *this;
    }

    int GetTriangleIndex() const { return m_index; }

    const HalfEdgeShared& GetHalfEdge() const { return m_halfEdge; }
    void SetHalfEdge(const HalfEdgeShared& halfEdge) { m_halfEdge = halfEdge; }

    bool CheckTriangleVisited() const { return m_visited; }
    void SetTriangleVisitedState(bool visited) { m_visited = visited; }

private:
    bool m_visited = false;
    int m_index;
    int m_ptIndex1;
    int m_ptIndex2;
    int m_ptIndex3;
    HalfEdgeShared m_halfEdge;
};

class LineVector
{
public:
    LineVector()
        : compX(0.0)
        , compY(0.0)
        , compZ(0.0)
    {
    }
    LineVector(Point& v0, Point& v1)
        : compX(v1.GetXCoord() - v0.GetXCoord())
        , compY(v1.GetYCoord() - v0.GetYCoord())
        , compZ(v1.GetZCoord() - v0.GetZCoord())
    {
    }
    LineVector(double x, double y, double z)
        : compX(x)
        , compY(y)
        , compZ(z)
    {
    }

    LineVector(const LineVector& vect)
        : compX(vect.compX)
        , compY(vect.compY)
        , compZ(vect.compZ)
    {
    }

    LineVector operator+(LineVector& vect)
    {
        compX += vect.compX, compY += vect.compY, compZ += vect.compZ;
        return *this;
    }

    LineVector operator-(LineVector& vect)
    {
        compX -= vect.compX, compY -= vect.compY, compZ -= vect.compZ;
        return *this;
    }

    bool operator==(const LineVector& lineVector) const
    {
        return fabs(
            (compX - lineVector.GetXComp()) < PointTolerance && fabs(compY - lineVector.GetYComp()) < PointTolerance &&
            fabs(compZ - lineVector.GetZComp()) < PointTolerance);
    }

    bool operator!=(const LineVector& lineVector) const { return !operator==(lineVector); }

    double& operator[](int index)
    {
        assert(index >= 0 && index < 3);

        if (index == 0) return compX;
        if (index == 1) return compY;
        return compZ;
    }

    double DotProduct(const LineVector& vect) { return (compX * vect.compX + compY * vect.compY + compZ * vect.compZ); }

    double MagnitudeSquare() const { return (compX * compX + compY * compY + compZ * compZ); }

    LineVector CrossProduct(const LineVector& vect);

    double IncludedAngle(const LineVector& vect);

    void Normalize();

    double Magnitude() const;

    void Flip();

    double GetXComp() const { return compX; }
    double GetYComp() const { return compY; }
    double GetZComp() const { return compZ; }

    Point PointAlongAVector(Point& pPt, double dist);

    double GetMagnitude() { return sqrt(compX * compX + compY * compY + compZ * compZ); }

private:
    double compX, compY, compZ;
};

using PointShared = shared_ptr<Point>;
using TriangleShared = shared_ptr<Triangle>;
using LineVectorShared = shared_ptr<LineVector>;

class TriaMesh
{
public:
    TriaMesh()
        : m_meshPoints(make_shared<vector<Point>>(vector<Point>()))
    {
    }
    shared_ptr<vector<Point>> m_meshPoints;
    vector<TriangleShared> m_meshTriangles;
    vector<LineVectorShared> m_meshNormals;
    void CalculateTriangleNormals(bool flipNormal = false);
    LineVector GetTriangleNormal(int index) const;
};

class TriaMeshSegregated : public TriaMesh
{
public:
    Point GetCentroid() const;
    vector<HalfEdgeShared> m_boundaryEdges;
};

class ParametrizedEdge
{
public:
    ParametrizedEdge(const vector<PointShared>& edgePoints);

    ParametrizedEdge(vector<PointShared>&& edgePoints);

    ParametrizedEdge(const ParametrizedEdge& paramEdge);

    Point GetParamterizedPoint(double value) const;

    bool operator==(const ParametrizedEdge& otherEdge) const
    {
        return (m_edgePointIndices == otherEdge.m_edgePointIndices);
    }

    bool operator<(const ParametrizedEdge& otherEdge) const
    {
        return (m_edgePointIndices < otherEdge.m_edgePointIndices);
    }

    const Point& GetCentroid() const { return m_centroid; }
    vector<PointShared> GetParametrizedEdgePoints(int numDivisions);

    double GetEdgeLength() const { return m_edgeLength; }

    void SetEdgePointIndices(const vector<size_t>& indices) { m_edgePointIndices = indices; }

private:
    double m_edgeLength;
    double EdgeLength() const;
    Point m_centroid;
    Point CalculateCentroid() const;
    vector<PointShared> m_parametrizedEdgePoints;
    vector<PointShared> m_edgePoints;
    vector<size_t> m_edgePointIndices;
};

using ParametrizedEdgeShared = shared_ptr<ParametrizedEdge>;

class ParametrizedFace
{
public:
    ParametrizedFace(const Point& centroid, const vector<ParametrizedEdgeShared>& paramEdges)
        : m_centroid(centroid)
        , m_parametrizedEdges(paramEdges)
    {
    }
    ParametrizedFace(const Point& centroid, vector<ParametrizedEdgeShared>&& paramEdges)
        : m_centroid(centroid)
        , m_parametrizedEdges(move(paramEdges))
    {
    }

    const vector<ParametrizedEdgeShared>& GetParametrizedEdges() const { return m_parametrizedEdges; }
    void SetParametrizedEdges(vector<ParametrizedEdgeShared>& edges) { m_parametrizedEdges = move(edges); }

    void SetXDivisions(int xDivisions) { m_xDivision = xDivisions; }
    void SetYDivisions(int yDivisions) { m_yDivision = yDivisions; }

    int GetXDivisions() const { return m_xDivision; }
    int GetYDivisions() const { return m_yDivision; }

    void SetParamterizedPoints(vector<vector<PointShared>>&& meshedPoints) { m_facePoints = std::move(meshedPoints); }

    const vector<vector<PointShared>>& GetParamterizedPoints() const { return m_facePoints; }

    const Point& GetCentroid() const { return m_centroid; }

private:
    int m_xDivision = 0, m_yDivision = 0;
    Point m_centroid;
    vector<ParametrizedEdgeShared> m_parametrizedEdges;
    vector<vector<PointShared>> m_facePoints;
};

using ParametrizedFaceShared = shared_ptr<ParametrizedFace>;
