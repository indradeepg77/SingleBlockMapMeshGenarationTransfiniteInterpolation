/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/
#pragma once

#include "MeshEntities.h"

using namespace std;

enum class InterpolationScheme
{
    Laplacian = 0,
    Transfinite
};

enum class EdgeOrder
{
    PositiveX,
    PositiveY,
    PositiveZ
};

class MapMeshAlgorithm
{
public:
    static void GenerateSurfaceMeshByTransfiniteInterpolation(
        const ParametrizedFaceShared& parametrizedFace,
        EdgeOrder uOrder,
        EdgeOrder vOrder);
    static vector<vector<vector<PointShared>>> GenerateVolumeMeshFromSurfaceMeshes(
        InterpolationScheme interplationMethod,
        const ParametrizedFaceShared& sideFacesC1,
        const ParametrizedFaceShared& sideFacesC2,
        const ParametrizedFaceShared& sideFacesC3,
        const ParametrizedFaceShared& sideFacesC4);

    static vector<vector<vector<PointShared>>> GenerateVolumeMeshByTransfiniteInterpolation(
        InterpolationScheme interplationMethod,
        const ParametrizedFaceShared& sideFacesBottom,
        const ParametrizedFaceShared& sideFacesTop,
        const ParametrizedFaceShared& sideFacesC1,
        const ParametrizedFaceShared& sideFacesC2,
        const ParametrizedFaceShared& sideFacesC3,
        const ParametrizedFaceShared& sideFacesC4);

private:
    static vector<vector<PointShared>> GenerateSurfaceMeshByTransfiniteInterpolation(
        const vector<PointShared>& c1,
        const vector<PointShared>& c2,
        const vector<PointShared>& c3,
        const vector<PointShared>& c4);

    static void LaplacianSmootheningOfSurfaceMesh(vector<vector<PointShared>>& meshData, double underrelaxFactor = 1.0);

    static void LaplacianSmootheningOfVolumeMesh(
        vector<vector<vector<PointShared>>>& meshData,
        double underrelaxFactor = 1.0);

    static Point TransfiniteInterpolation(
        double u,
        double v,
        const Point& c1u,
        const Point& c3u,
        const Point& c2v,
        const Point& c4v,
        const Point& p12,
        const Point& p34,
        const Point& p14,
        const Point& p32);
    static void TransfiniteInterpolationIn3D(
        int xNumPoints,
        int yNumPoints,
        int zNumPoints,
        int xIndex,
        int yIndex,
        int zIndex,
        vector<vector<vector<PointShared>>>& volumeMesh);
};
