/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

// MeshEntities.cpp : Defines the entry point for the console application.
//

#include "../Header/MeshEntities.h"

using namespace std;

constexpr double PI = 3.1415926535897932384626433832795;

LineVector LineVector::CrossProduct(const LineVector& vect)
{
    LineVector m_crossProd;
    m_crossProd.compX = compY * vect.compZ - vect.compY * compZ;
    m_crossProd.compY = vect.compX * compZ - compX * vect.compZ;
    m_crossProd.compZ = compX * vect.compY - vect.compX * compY;
    return m_crossProd;
}

double LineVector::Magnitude() const
{
    return sqrt(MagnitudeSquare());
}

void LineVector::Normalize()
{
    double magnitudeValue = Magnitude();
    if (magnitudeValue < 1e-8) return;
    compX /= magnitudeValue;
    compY /= magnitudeValue;
    compZ /= magnitudeValue;
}

double LineVector::IncludedAngle(const LineVector& vect)
{
    return acos(fabs(DotProduct(vect))) * 180.0 / PI;
}

void LineVector::Flip()
{
    compX *= -1.;
    compY *= -1.;
    compZ *= -1.;
}

Point LineVector::PointAlongAVector(Point& pPt, double dist)
{
    Point mPointAlongLine;
    mPointAlongLine[0] = pPt[0] + compX * dist;
    mPointAlongLine[1] = pPt[1] + compY * dist;
    mPointAlongLine[2] = pPt[2] + compZ * dist;
    return mPointAlongLine;
}

void TriaMesh::CalculateTriangleNormals(bool flipNormal)
{
    for (const TriangleShared& triaData : m_meshTriangles)
    {
        Point pt1 = m_meshPoints->at(triaData->GetPointIndex(0));
        Point pt2 = m_meshPoints->at(triaData->GetPointIndex(1));
        Point pt3 = m_meshPoints->at(triaData->GetPointIndex(2));
        LineVector normal = LineVector(pt1, pt2).CrossProduct(LineVector(pt1, pt3));
        normal.Normalize();
        if (flipNormal) normal.Flip();
        m_meshNormals.push_back(make_shared<LineVector>(normal));
    }
}

Point TriaMeshSegregated::GetCentroid() const
{
    int count = 0;
    Point centroid;
    for (const TriangleShared& triaData : m_meshTriangles)
    {
        Point pt1 = m_meshPoints->at(triaData->GetPointIndex(0));
        Point pt2 = m_meshPoints->at(triaData->GetPointIndex(1));
        Point pt3 = m_meshPoints->at(triaData->GetPointIndex(2));
        Point triangleCenter = (pt1 + pt2 + pt3);
        triangleCenter /= 3.0;

        centroid += triangleCenter;
        count++;
    }
    centroid /= count;
    return centroid;
}

LineVector TriaMesh::GetTriangleNormal(int index) const
{
    return *m_meshNormals.at(index);
}

bool HalfEdge::operator<(const HalfEdge& otherEdge)
{
    int index1 = sourceNodeIndex;
    int index2 = targetNodeIndex;
    if (sourceNodeIndex > targetNodeIndex)
    {
        index1 = targetNodeIndex;
        index2 = sourceNodeIndex;
    }
    int otherIndex1 = otherEdge.sourceNodeIndex;
    int otherIndex2 = otherEdge.targetNodeIndex;
    if (otherIndex1 > otherIndex2)
    {
        otherIndex1 = otherEdge.targetNodeIndex;
        otherIndex2 = otherEdge.sourceNodeIndex;
    }
    if (index1 < otherIndex1) return true;
    if ((index1 == otherIndex1) && (index2 < otherIndex2)) return true;
    return false;
}

bool HalfEdge::operator==(const HalfEdge& otherEdge)
{
    if (sourceNodeIndex != otherEdge.sourceNodeIndex) return false;
    if (targetNodeIndex != otherEdge.targetNodeIndex) return false;
    return true;
}

bool HalfEdge::IsTwinEdge(const HalfEdge& otherEdge)
{
    // If source node index of edge 1 = target node index of edge 2 and 
    // if target node index of edge 1 = source node index of edge 2
    // The edges are twin edges to each other
    if (sourceNodeIndex != otherEdge.targetNodeIndex) return false;
    if (targetNodeIndex != otherEdge.sourceNodeIndex) return false;
    return true;
}

double ParametrizedEdge::EdgeLength() const
{
    double length = 0.0;
    for (size_t index = 0; index < m_edgePoints.size() - 1; ++index)
    {
        length += LineVector(*m_edgePoints.at(index), *m_edgePoints.at(index + 1)).Magnitude();
    }
    return length;
}

ParametrizedEdge::ParametrizedEdge(const vector<PointShared>& edgePoints)
    : m_edgePoints(edgePoints)
{
    m_edgeLength = EdgeLength();
    m_centroid = CalculateCentroid();
}
ParametrizedEdge::ParametrizedEdge(vector<PointShared>&& edgePoints)
    : m_edgePoints(move(edgePoints))
{
    m_edgeLength = EdgeLength();
    m_centroid = CalculateCentroid();
}

ParametrizedEdge::ParametrizedEdge(const ParametrizedEdge& paramEdge)
    : m_edgePoints(paramEdge.m_edgePoints)
{
    m_edgeLength = EdgeLength();
    m_centroid = CalculateCentroid();
}

Point ParametrizedEdge::GetParamterizedPoint(double value) const
{
    if (fabs(value) < 1e-4) return *m_edgePoints.at(0);
    if (fabs(value) > 0.9999) return *m_edgePoints.at(m_edgePoints.size() - 1);
    double paramLength = value * EdgeLength();
    double length = 0.0;
    for (size_t index = 0; index < m_edgePoints.size() - 1; ++index)
    {
        double backupLength = length;
        length += LineVector(*m_edgePoints.at(index), *m_edgePoints.at(index + 1)).Magnitude();

        if (paramLength > backupLength && paramLength < length)
        {
            double weight = (paramLength - backupLength) / (length - backupLength);
            return Point::WightedAveragePoints(*m_edgePoints.at(index), *m_edgePoints.at(index + 1), weight);
        }
    }
    return Point();
}

Point ParametrizedEdge::CalculateCentroid() const
{
    int count = 0;
    Point centroid;
    for (const PointShared& point : m_edgePoints)
    {
        centroid += *point;
        count++;
    }
    return centroid / count;
}

vector<PointShared> ParametrizedEdge::GetParametrizedEdgePoints(int numDivisions)
{
    if (!m_parametrizedEdgePoints.empty()) return m_parametrizedEdgePoints;
    int numPoints = numDivisions + 1;
    for (int i = 1; i <= numPoints; ++i)
    {
        double value = static_cast<double>(i - 1) / numDivisions;
        m_parametrizedEdgePoints.push_back(make_shared<Point>(GetParamterizedPoint(value)));
    }
    return m_parametrizedEdgePoints;
}
