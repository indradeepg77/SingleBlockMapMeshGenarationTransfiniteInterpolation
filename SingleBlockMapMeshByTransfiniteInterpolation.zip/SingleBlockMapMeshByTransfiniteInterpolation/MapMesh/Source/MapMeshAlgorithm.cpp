﻿/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

// MapMeshAlgorithm.cpp
//

#include "../Header/MapMeshAlgorithm.h"
#include "../Header/MeshUtils.h"

using namespace std;

Point MapMeshAlgorithm::TransfiniteInterpolation(
    double u,
    double v,
    const Point& c1u,
    const Point& c3u,
    const Point& c2v,
    const Point& c4v,
    const Point& p12,
    const Point& p34,
    const Point& p14,
    const Point& p32)
{
    double compu = 1.0 - u;
    double compv = 1.0 - v;

    Point firstComponent = c1u * compv + c3u * v + c2v * compu + c4v * u;
    Point secondComponent = p14 * (u * compv) + p32 * (compu * v) + p34 * (u * v) + p12 * (compv * compu);

    return (firstComponent - secondComponent);
}

vector<vector<PointShared>> MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
    const vector<PointShared>& c1,
    const vector<PointShared>& c2,
    const vector<PointShared>& c3,
    const vector<PointShared>& c4)
{
    // 2D planer mesh
    vector<vector<PointShared>> generatedMesh;
    size_t xNumPoints = c1.size();
    size_t yNumPoints = c2.size();
    generatedMesh.resize(xNumPoints);
    for_each(
        generatedMesh.begin(), generatedMesh.end(),
        [yNumPoints](vector<PointShared>& ptArray) { ptArray.resize(yNumPoints); });

    Point p12 = *c1.at(0);
    Point p34 = *c3.at(c3.size() - 1);
    Point p14 = *c1.at(c1.size() - 1);
    Point p32 = *c3.at(0);

    for (size_t xIndex = 0; xIndex < xNumPoints; ++xIndex)
    {
        double u = static_cast<double>(xIndex) / (xNumPoints - 1);
        Point c1u = *c1.at(xIndex);
        Point c3u = *c3.at(xIndex);

        for (size_t yIndex = 0; yIndex < yNumPoints; ++yIndex)
        {
            double v = static_cast<double>(yIndex) / (yNumPoints - 1);
            Point c2v = *c2.at(yIndex);
            Point c4v = *c4.at(yIndex);

            generatedMesh[xIndex][yIndex] =
                make_shared<Point>(TransfiniteInterpolation(u, v, c1u, c3u, c2v, c4v, p12, p34, p14, p32));
        }
    }
    return generatedMesh;
}

void MapMeshAlgorithm::TransfiniteInterpolationIn3D(
    int xNumPoints,
    int yNumPoints,
    int zNumPoints,
    int xIndex,
    int yIndex,
    int zIndex,
    vector<vector<vector<PointShared>>>& volumeMesh)
{
    double x = static_cast<double>(xIndex) / (xNumPoints - 1);
    double y = static_cast<double>(yIndex) / (yNumPoints - 1);
    double z = static_cast<double>(zIndex) / (zNumPoints - 1);
    double compx = 1.0 - x;
    double compy = 1.0 - y;
    double compz = 1.0 - z;

    Point firstComponent =
        (*volumeMesh[0][yIndex][zIndex]) * compx + (*volumeMesh[xNumPoints - 1][yIndex][zIndex]) * x +
        (*volumeMesh[xIndex][0][zIndex]) * compy + (*volumeMesh[xIndex][yNumPoints - 1][zIndex]) * y +
        (*volumeMesh[xIndex][yIndex][0]) * compz + (*volumeMesh[xIndex][yIndex][zNumPoints - 1]) * z;

    Point secondComponent =
        ((*volumeMesh[0][0][zIndex]) * compy + (*volumeMesh[0][yNumPoints - 1][zIndex]) * y) * compx +
        ((*volumeMesh[xNumPoints - 1][0][zIndex]) * compy + (*volumeMesh[xNumPoints - 1][yNumPoints - 1][zIndex]) * y) *
            x +
        ((*volumeMesh[xIndex][0][0]) * compz + (*volumeMesh[xIndex][0][zNumPoints - 1]) * z) * compy +
        ((*volumeMesh[xIndex][yNumPoints - 1][0]) * compz + (*volumeMesh[xIndex][yNumPoints - 1][zNumPoints - 1]) * z) *
            y +
        ((*volumeMesh[0][yIndex][0]) * compx + (*volumeMesh[xNumPoints - 1][yIndex][0]) * x) * compz +
        ((*volumeMesh[0][yIndex][zNumPoints - 1]) * compx + (*volumeMesh[xNumPoints - 1][yIndex][zNumPoints - 1]) * x) *
            z;

    Point thirdComponent =
        (((*volumeMesh[0][0][0]) * compz + (*volumeMesh[0][0][zNumPoints - 1]) * z) * compy +
         ((*volumeMesh[0][yNumPoints - 1][0]) * compz + (*volumeMesh[0][yNumPoints - 1][zNumPoints - 1]) * z) * y) *
            compx +
        (((*volumeMesh[xNumPoints - 1][0][0]) * compz + (*volumeMesh[xNumPoints - 1][0][zNumPoints - 1]) * z) * compy +
         ((*volumeMesh[xNumPoints - 1][yNumPoints - 1][0]) * compz +
          (*volumeMesh[xNumPoints - 1][yNumPoints - 1][zNumPoints - 1]) * z) *
             y) *
            x;

    volumeMesh[xIndex][yIndex][zIndex] = make_shared<Point>(firstComponent - secondComponent + thirdComponent);
}

void MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
    const ParametrizedFaceShared& parametrizedFace,
    EdgeOrder uOrder,
    EdgeOrder vOrder)
{
    /// <summary>
    /// Surface edges should be in following order
    ///     C3(u)
    /// ---------->
    /// ^         ^
    /// |         |
    /// |C2(v)    |C4(v)
    /// |         |
    /// ---------->
    ///     C1(u)
    /// </summary>
    /// <param name="parametrizedFace"></param>

    vector<ParametrizedEdgeShared> edgesSurface = parametrizedFace->GetParametrizedEdges();
    // Number of points are one more than number of divisions
    int xDivisions = parametrizedFace->GetXDivisions();
    int yDivisions = parametrizedFace->GetYDivisions();

    auto CompareEdgeCentroidComp =
        [](EdgeOrder order, const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2)
    {
        if (order == EdgeOrder::PositiveX) return edge1->GetCentroid().GetXCoord() < edge2->GetCentroid().GetXCoord();
        if (order == EdgeOrder::PositiveY) return edge1->GetCentroid().GetYCoord() < edge2->GetCentroid().GetYCoord();
        if (order == EdgeOrder::PositiveZ) return edge1->GetCentroid().GetZCoord() < edge2->GetCentroid().GetZCoord();
        return false;
    };

    sort(
        edgesSurface.begin(), edgesSurface.end(),
        [&](const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2)
        { return CompareEdgeCentroidComp(vOrder, edge1, edge2); });

    vector<PointShared> c1 = edgesSurface.at(0)->GetParametrizedEdgePoints(xDivisions);
    vector<PointShared> c3 = edgesSurface.at(edgesSurface.size() - 1)->GetParametrizedEdgePoints(xDivisions);

    sort(
        edgesSurface.begin(), edgesSurface.end(),
        [&](const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2)
        { return CompareEdgeCentroidComp(uOrder, edge1, edge2); });

    vector<PointShared> c2 = edgesSurface.at(0)->GetParametrizedEdgePoints(yDivisions);
    vector<PointShared> c4 = edgesSurface.at(edgesSurface.size() - 1)->GetParametrizedEdgePoints(yDivisions);

    auto OrderEdges = [](EdgeOrder order, vector<PointShared>& points)
    {
        bool reverseEdge = false;
        size_t endIndex = points.size() - 1;
        if (order == EdgeOrder::PositiveX) reverseEdge = points[0]->GetXCoord() > points[endIndex]->GetXCoord();
        if (order == EdgeOrder::PositiveY) reverseEdge = points[0]->GetYCoord() > points[endIndex]->GetYCoord();
        if (order == EdgeOrder::PositiveZ) reverseEdge = points[0]->GetZCoord() > points[endIndex]->GetZCoord();
        if (reverseEdge) reverse(points.begin(), points.end());
    };

    OrderEdges(uOrder, c1);
    OrderEdges(vOrder, c2);
    OrderEdges(uOrder, c3);
    OrderEdges(vOrder, c4);

    parametrizedFace->SetParamterizedPoints(GenerateSurfaceMeshByTransfiniteInterpolation(c1, c2, c3, c4));
}

void MapMeshAlgorithm::LaplacianSmootheningOfSurfaceMesh(vector<vector<PointShared>>& meshData, double underrelaxFactor)
{
    // 2D planer mesh
    vector<vector<PointShared>> smoothMesh;
    size_t xNumPoints = meshData.size();
    size_t yNumPoints = meshData[0].size();
    smoothMesh.resize(xNumPoints - 1);
    for_each(
        smoothMesh.begin(), smoothMesh.end(),
        [yNumPoints](vector<PointShared>& ptArray) { ptArray.resize(yNumPoints - 1); });

    for (size_t xIndex = 1; xIndex < xNumPoints - 1; ++xIndex)
    {
        for (size_t yIndex = 1; yIndex < yNumPoints - 1; ++yIndex)
        {
            Point avgPt;
            for (const Point& pt :
                 {*meshData[xIndex - 1][yIndex], *meshData[xIndex + 1][yIndex], *meshData[xIndex][yIndex - 1],
                  *meshData[xIndex][yIndex + 1]})
            {
                avgPt += pt;
            }

            avgPt = avgPt * (0.25 * underrelaxFactor) + *meshData[xIndex][yIndex] * (1.0 - underrelaxFactor);

            smoothMesh[xIndex - 1][yIndex - 1] = make_shared<Point>(avgPt);
        }
    }
    for (size_t i = 1; i < xNumPoints - 1; ++i)
        for (size_t j = 1; j < yNumPoints - 1; ++j)
            meshData[i][j] = smoothMesh[i - 1][j - 1];
}

void MapMeshAlgorithm::LaplacianSmootheningOfVolumeMesh(
    vector<vector<vector<PointShared>>>& meshData,
    double underrelaxFactor)
{
    // 2D planer mesh
    vector<vector<vector<PointShared>>> smoothMesh;
    size_t xNumPoints = meshData.size();
    size_t yNumPoints = meshData[0].size();
    size_t zNumPoints = meshData[0][0].size();
    smoothMesh.resize(xNumPoints - 1);
    for_each(
        smoothMesh.begin(), smoothMesh.end(),
        [yNumPoints, zNumPoints](vector<vector<PointShared>>& pt2DArray)
        {
            pt2DArray.resize(yNumPoints - 1);
            for_each(
                pt2DArray.begin(), pt2DArray.end(),
                [zNumPoints](vector<PointShared>& ptArray) { ptArray.resize(zNumPoints - 1); });
        });

    for (size_t xIndex = 1; xIndex < xNumPoints - 1; ++xIndex)
    {
        for (size_t yIndex = 1; yIndex < yNumPoints - 1; ++yIndex)
        {
            for (size_t zIndex = 1; zIndex < zNumPoints - 1; ++zIndex)
            {
                Point avgPt;
                for (const Point& pt :
                     {*meshData[xIndex - 1][yIndex][zIndex], *meshData[xIndex + 1][yIndex][zIndex],
                      *meshData[xIndex][yIndex - 1][zIndex], *meshData[xIndex][yIndex + 1][zIndex],
                      *meshData[xIndex][yIndex][zIndex - 1], *meshData[xIndex][yIndex][zIndex + 1]})
                {
                    avgPt += pt;
                }

                avgPt = avgPt * (underrelaxFactor / 6.0) + *meshData[xIndex][yIndex][zIndex] * (1.0 - underrelaxFactor);

                smoothMesh[xIndex - 1][yIndex - 1][zIndex - 1] = make_shared<Point>(avgPt);
            }
        }
    }
    for (size_t i = 1; i < xNumPoints - 1; ++i)
        for (size_t j = 1; j < yNumPoints - 1; ++j)
            for (size_t k = 1; k < zNumPoints - 1; ++k)
                meshData[i][j][k] = smoothMesh[i - 1][j - 1][k - 1];
}

vector<vector<vector<PointShared>>> MapMeshAlgorithm::GenerateVolumeMeshFromSurfaceMeshes(
    InterpolationScheme interplationMethod,
    const ParametrizedFaceShared& sideFacesC1,
    const ParametrizedFaceShared& sideFacesC2,
    const ParametrizedFaceShared& sideFacesC3,
    const ParametrizedFaceShared& sideFacesC4)
{
    const vector<vector<PointShared>>& sideFaceC1Points = sideFacesC1->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC2Points = sideFacesC2->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC3Points = sideFacesC3->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC4Points = sideFacesC4->GetParamterizedPoints();

    int xNumPoints = sideFacesC1->GetXDivisions() + 1;
    int yNumPoints = sideFacesC2->GetXDivisions() + 1;
    int zNumPoints = sideFacesC1->GetYDivisions() + 1;
    vector<PointShared> c1;
    vector<PointShared> c2;
    vector<PointShared> c3;
    vector<PointShared> c4;
    vector<vector<vector<PointShared>>> volumeMeshData;
    volumeMeshData.resize(xNumPoints);
    for_each(
        volumeMeshData.begin(), volumeMeshData.end(),
        [yNumPoints, zNumPoints](vector<vector<PointShared>>& pt2DArray)
        {
            pt2DArray.resize(yNumPoints);
            for_each(
                pt2DArray.begin(), pt2DArray.end(),
                [zNumPoints](vector<PointShared>& ptArray) { ptArray.resize(zNumPoints); });
        });

    for (int k = 0; k < zNumPoints; k++)
    {
        for (int i = 0; i < xNumPoints; i++)
            c1.push_back(sideFaceC1Points[i][k]);
        for (int i = 0; i < yNumPoints; i++)
            c2.push_back(sideFaceC2Points[i][k]);
        for (int i = 0; i < xNumPoints; i++)
            c3.push_back(sideFaceC3Points[i][k]);
        for (int i = 0; i < yNumPoints; i++)
            c4.push_back(sideFaceC4Points[i][k]);

        vector<vector<PointShared>> meshData =
            MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(c1, c2, c3, c4);

        c1.clear();
        c2.clear();
        c3.clear();
        c4.clear();

        if (interplationMethod == InterpolationScheme::Laplacian)
            MapMeshAlgorithm::LaplacianSmootheningOfSurfaceMesh(meshData);

        for (int i = 0; i < xNumPoints; i++)
            for (int j = 0; j < yNumPoints; j++)
                volumeMeshData[i][j][k] = meshData[i][j];
    }

    return volumeMeshData;
}

vector<vector<vector<PointShared>>> MapMeshAlgorithm::GenerateVolumeMeshByTransfiniteInterpolation(
    InterpolationScheme interplationMethod,
    const ParametrizedFaceShared& sideFacesBottom,
    const ParametrizedFaceShared& sideFacesTop,
    const ParametrizedFaceShared& sideFacesC1,
    const ParametrizedFaceShared& sideFacesC2,
    const ParametrizedFaceShared& sideFacesC3,
    const ParametrizedFaceShared& sideFacesC4)
{
    const vector<vector<PointShared>>& sideFaceBottomPoints = sideFacesBottom->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceTopPoints = sideFacesTop->GetParamterizedPoints();

    const vector<vector<PointShared>>& sideFaceC1Points = sideFacesC1->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC2Points = sideFacesC2->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC3Points = sideFacesC3->GetParamterizedPoints();
    const vector<vector<PointShared>>& sideFaceC4Points = sideFacesC4->GetParamterizedPoints();

    int xNumPoints = sideFacesC1->GetXDivisions() + 1;
    int yNumPoints = sideFacesC2->GetXDivisions() + 1;
    int zNumPoints = sideFacesC1->GetYDivisions() + 1;

    vector<vector<vector<PointShared>>> volumeMeshData;
    volumeMeshData.resize(xNumPoints);
    for_each(
        volumeMeshData.begin(), volumeMeshData.end(),
        [yNumPoints, zNumPoints](vector<vector<PointShared>>& pt2DArray)
        {
            pt2DArray.resize(yNumPoints);
            for_each(
                pt2DArray.begin(), pt2DArray.end(),
                [zNumPoints](vector<PointShared>& ptArray) { ptArray.resize(zNumPoints); });
        });

    for (size_t i = 0; i < xNumPoints; i++)
    {
        for (size_t j = 0; j < yNumPoints; j++)
        {
            volumeMeshData[i][j][0] = sideFaceBottomPoints[i][j];
            volumeMeshData[i][j][zNumPoints - 1] = sideFaceTopPoints[i][j];
        }
    }

    for (size_t i = 0; i < xNumPoints; i++)
    {
        for (size_t k = 0; k < zNumPoints; k++)
        {
            volumeMeshData[i][0][k] = sideFaceC1Points[i][k];
            volumeMeshData[i][yNumPoints - 1][k] = sideFaceC3Points[i][k];
        }
    }

    for (size_t j = 0; j < yNumPoints; j++)
    {
        for (size_t k = 0; k < zNumPoints; k++)
        {
            volumeMeshData[0][j][k] = sideFaceC2Points[j][k];
            volumeMeshData[xNumPoints - 1][j][k] = sideFaceC4Points[j][k];
        }
    }

    for (int i = 1; i < xNumPoints - 1; i++)
    {
        for (int j = 1; j < yNumPoints - 1; j++)
        {
            for (int k = 1; k < zNumPoints - 1; k++)
            {
                MapMeshAlgorithm::TransfiniteInterpolationIn3D(
                    xNumPoints, yNumPoints, zNumPoints, i, j, k, volumeMeshData);

                if (interplationMethod == InterpolationScheme::Laplacian)
                    MapMeshAlgorithm::LaplacianSmootheningOfVolumeMesh(volumeMeshData);
            }
        }
    }

    return volumeMeshData;
}
