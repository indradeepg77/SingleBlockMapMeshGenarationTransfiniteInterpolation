/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/


// MapMesh.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "../Header/MeshUtils.h"
#include "../Header/MapMeshAlgorithm.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

int main()
{
    // Read input triangles and points and put it in the list
    TriaMesh inputMesh = ReadInitializeTriangularData();

    if (inputMesh.m_meshPoints->empty()) return -1;

    OutputTriangularData(inputMesh, "..\\OutputData\\outputMesh.stl");

    int laplaceSmoothen = 0;
    int xDivisions = 10;
    int yDivisions = 15;
    int zDivisions = 20;
    InterpolationScheme interpolationScheme = InterpolationScheme::Transfinite;

    // Read the data from the input file
    ifstream in("..\\InputFiles\\input_information.txt");

    if (!in)
    {
        cout << "Cannot open input information file.\n";
    }
    std::string line;

    std::getline(in, line);
    std::istringstream iss(line);
    iss >> xDivisions >> yDivisions >> zDivisions;
    std::getline(in, line);
    iss >> laplaceSmoothen;

    in.close();

    if (laplaceSmoothen) interpolationScheme = InterpolationScheme::Laplacian;

    vector<TriaMeshSegregated> triangularPatches = ComputeTriangularPatchesDFSBased(inputMesh);

    vector<ParametrizedFaceShared> sideFacesParametrized;

    for (size_t count = 0; count < triangularPatches.size(); count++)
    {
        string patchFileName = "..\\OutputData\\outputPatchFile" + to_string(count + 1) + ".stl";
        OutputTriangularData(triangularPatches.at(count), patchFileName);

        vector<FaceSideEdge> sideEdges = ComputeSurfaceEdges(triangularPatches.at(count));

        ParametrizedFaceShared sideFaceParametrized =
            CreateParametrizedFaceFromSideEdges(triangularPatches.at(count), sideEdges);

        sideFacesParametrized.emplace_back(sideFaceParametrized);
    }

    // Some of the edges between the faces are common. Just assign the unique edges on all the
    // faces so that parametrization and common nodes will be easy to find during meshing
    UpdateParametrizedFaceWithUniqueParametrizedEdges(sideFacesParametrized);

    sort(
        sideFacesParametrized.begin(), sideFacesParametrized.end(),
        [](const ParametrizedFaceShared& face1, const ParametrizedFaceShared& face2)
        { return face1->GetCentroid().GetYCoord() < face2->GetCentroid().GetYCoord(); });

    ParametrizedFaceShared sideFaceC1 = sideFacesParametrized.at(0);
    ParametrizedFaceShared sideFaceC3 = sideFacesParametrized.at(sideFacesParametrized.size() - 1);

    sort(
        sideFacesParametrized.begin(), sideFacesParametrized.end(),
        [](const ParametrizedFaceShared& face1, const ParametrizedFaceShared& face2)
        { return face1->GetCentroid().GetXCoord() < face2->GetCentroid().GetXCoord(); });

    ParametrizedFaceShared sideFaceC2 = sideFacesParametrized.at(0);
    ParametrizedFaceShared sideFaceC4 = sideFacesParametrized.at(sideFacesParametrized.size() - 1);

    sort(
        sideFacesParametrized.begin(), sideFacesParametrized.end(),
        [](const ParametrizedFaceShared& face1, const ParametrizedFaceShared& face2)
        { return face1->GetCentroid().GetZCoord() < face2->GetCentroid().GetZCoord(); });

    ParametrizedFaceShared sideFaceBottom = sideFacesParametrized.at(0);
    ParametrizedFaceShared sideFaceTop = sideFacesParametrized.at(sideFacesParametrized.size() - 1);

    sideFaceC1->SetXDivisions(xDivisions);
    sideFaceC1->SetYDivisions(zDivisions);
    sideFaceC3->SetXDivisions(xDivisions);
    sideFaceC3->SetYDivisions(zDivisions);

    sideFaceC2->SetXDivisions(yDivisions);
    sideFaceC2->SetYDivisions(zDivisions);
    sideFaceC4->SetXDivisions(yDivisions);
    sideFaceC4->SetYDivisions(zDivisions);

    sideFaceBottom->SetXDivisions(xDivisions);
    sideFaceBottom->SetYDivisions(yDivisions);
    sideFaceTop->SetXDivisions(xDivisions);
    sideFaceTop->SetYDivisions(yDivisions);

    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceC1, EdgeOrder::PositiveX, EdgeOrder::PositiveZ);
    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceC2, EdgeOrder::PositiveY, EdgeOrder::PositiveZ);
    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceC3, EdgeOrder::PositiveX, EdgeOrder::PositiveZ);
    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceC4, EdgeOrder::PositiveY, EdgeOrder::PositiveZ);

    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceBottom, EdgeOrder::PositiveX, EdgeOrder::PositiveY);
    MapMeshAlgorithm::GenerateSurfaceMeshByTransfiniteInterpolation(
        sideFaceTop, EdgeOrder::PositiveX, EdgeOrder::PositiveY);

    vector<vector<vector<PointShared>>> volumeMesh = MapMeshAlgorithm::GenerateVolumeMeshFromSurfaceMeshes(
        interpolationScheme, sideFaceC1, sideFaceC2, sideFaceC3, sideFaceC4);

    OutputLayerMeshData(sideFaceC1->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceC1.stl");
    OutputLayerMeshData(sideFaceC2->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceC2.stl");
    OutputLayerMeshData(sideFaceC3->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceC3.stl");
    OutputLayerMeshData(sideFaceC4->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceC4.stl");
    OutputLayerMeshData(sideFaceBottom->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceBottom.stl");
    OutputLayerMeshData(sideFaceTop->GetParamterizedPoints(), "..\\OutputData\\OutputSideFaceTop.stl");

    auto OutputMeshDataLayerwise =
        [xDivisions, yDivisions,
         zDivisions](const vector<vector<vector<PointShared>>>& volumeMeshData, const string& outputFile)
    {
        int xNumPoints = xDivisions + 1;
        int yNumPoints = yDivisions + 1;
        int zNumPoints = zDivisions + 1;
        for (int k = 0; k < zNumPoints; k++)
        {
            vector<vector<PointShared>> meshData;
            meshData.resize(xNumPoints);
            for_each(
                meshData.begin(), meshData.end(),
                [yNumPoints](vector<PointShared>& ptArray) { ptArray.resize(yNumPoints); });
            for (int i = 0; i < xNumPoints; i++)
                for (int j = 0; j < yNumPoints; j++)
                    meshData[i][j] = volumeMeshData[i][j][k];
            string outputFileName = outputFile + to_string(k + 1) + ".stl";

            OutputLayerMeshData(meshData, outputFileName);
        }
    };
    OutputMeshDataLayerwise(volumeMesh, "..\\OutputData\\outputLayerFile");
    OutputVolumeMeshData(volumeMesh, "..\\OutputData\\outputVolumeMesh.plot3d");

    vector<vector<vector<PointShared>>> volumeMeshTransfinite =
        MapMeshAlgorithm::GenerateVolumeMeshByTransfiniteInterpolation(
            interpolationScheme, sideFaceBottom, sideFaceTop, sideFaceC1, sideFaceC2, sideFaceC3, sideFaceC4);

    OutputMeshDataLayerwise(volumeMeshTransfinite, "..\\OutputData\\outputLayerFileTransfinite");
    OutputVolumeMeshData(volumeMesh, "..\\OutputData\\outputVolumeMeshTransfinite.plot3d");

    cout << endl;

    system("pause");

    return 0;
}
