/*
    Copyright (c) 2023 Indradeep Ghosh

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

// MeshUtils.cpp : This file contains all the utility functions

#include "../Header/MeshUtils.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <deque>

using namespace std;

using EdgeNodeEdgeOrderMap = multimap<int, int>;

TriaMesh ReadInitializeTriangularData()
{
    // Read the data from the input file
    ifstream in("..\\InputFiles\\boundary_sheet.tria");

    if (!in)
    {
        cout << "Cannot open input file.\n";
        return {};
    }

    TriaMesh inputTriaMesh;
    std::string line;
    int index = 0;
    int thickness = 0;

    std::getline(in, line);
    int numPoints = std::stoi(line);
    while (std::getline(in, line))
    {
        std::istringstream iss(line);
        double v1, v2, v3;
        if (!(iss >> v1 >> v2 >> v3))
        {
            break;
        }
        inputTriaMesh.m_meshPoints->push_back({v1, v2, v3});
    }
    int numTriangles = std::stoi(line);
    while (std::getline(in, line))
    {
        std::istringstream iss(line);
        int v1, v2, v3;
        if (!(iss >> v1 >> v2 >> v3 >> thickness))
        {
            break;
        }
        inputTriaMesh.m_meshTriangles.push_back(std::make_shared<Triangle>(index, (v1 - 1), (v2 - 1), (v3 - 1)));
        index++;
    }

    in.close();

    inputTriaMesh.CalculateTriangleNormals(true);

    return inputTriaMesh;
}

bool OutputTriangularData(const TriaMesh& inputTriaMesh, const string& outputFileName)
{
    ofstream outFile(outputFileName, ios::out);

    outFile << "Surface STL generated as Output" << endl;

    int index = 0;
    for (const TriangleShared& trinagleData : inputTriaMesh.m_meshTriangles)
    {
        LineVector facetNormal = inputTriaMesh.GetTriangleNormal(index);
        outFile << "\tfacet normal " << -facetNormal[0] << " " << -facetNormal[1] << " " << -facetNormal[2] << endl;
        outFile << "\t outer loop" << endl;
        for (int i = 0; i < 3; ++i)
        {
            Point triaPt = inputTriaMesh.m_meshPoints->at(trinagleData->GetPointIndex(2-i));
            outFile << "\t  vertex " << triaPt.GetXCoord() << " " << triaPt.GetYCoord() << " " << triaPt.GetZCoord()
                    << endl;
        }
        outFile << "\t endloop" << endl;
        outFile << "\tendfacet" << endl;
    }

    outFile << "endsolid vcg" << endl;

    outFile.close();

    return true;
}

void CreateHalfEdgeStructure(const TriaMesh& inputTriaMesh)
{
    /*
        Loop through all the triangles and create the edges by nodes for each edge. Sort those edges by ascending order
        and put those in a sorted list.
        Go through the triangle list, get the upper and lower bound of the edges and for each half edge assign the 
        corresponding twin edge, by finding out from its upper and lower bounds. 
        Also for each of the edges specify the adjacent triangle.
        For each of the half edge assign its next from the lower and lower bounds of duplicate edges from the edge list.
        Store only one half edge in each of the triangles.
    */
    vector<HalfEdgeShared> halfEdgeList;
    int triangleIndex = 0;
    for (const TriangleShared& triangle : inputTriaMesh.m_meshTriangles)
    {
        for (int i = 0; i < 3; ++i)
        {
            halfEdgeList.push_back(
                make_shared<HalfEdge>(triangle->GetPointIndex(i), triangle->GetPointIndex((i + 1) % 3)));
        }
    }
    sort(
        halfEdgeList.begin(), halfEdgeList.end(),
        [](const HalfEdgeShared& edge1, const HalfEdgeShared& edge2) { return *edge1 < *edge2; });

    for (const TriangleShared& triangle : inputTriaMesh.m_meshTriangles)
    {
        HalfEdgeShared halfEdge = nullptr;

        for (int i = 0; i < 3; ++i)
        {
            HalfEdgeShared halfEdgeToFind =
                make_shared<HalfEdge>(triangle->GetPointIndex(i), triangle->GetPointIndex((i + 1) % 3));

            auto itrVectorLower = lower_bound(
                halfEdgeList.begin(), halfEdgeList.end(), halfEdgeToFind,
                [](const HalfEdgeShared& edge1, const HalfEdgeShared& edge2) { return *edge1 < *edge2; });

            assert(itrVectorLower != halfEdgeList.end());

            auto itrVectorUpper = itrVectorLower + 1;

            if ((itrVectorUpper != halfEdgeList.end()) && (*itrVectorLower)->IsTwinEdge(*(*itrVectorUpper)))
                (*itrVectorLower)->twinEdge = (*itrVectorUpper);
            if ((itrVectorUpper != halfEdgeList.end()) && (*itrVectorUpper)->IsTwinEdge(*(*itrVectorLower)))
                (*itrVectorUpper)->twinEdge = (*itrVectorLower);

            if (*halfEdgeToFind == *(*itrVectorLower))
            {
                (*itrVectorLower)->adjTriangleIndex = triangle->GetTriangleIndex();
                if (i == 0) halfEdge = *itrVectorLower;
                if (i == 1) halfEdge->nextEdge = *itrVectorLower;
                if (i == 2) halfEdge->nextEdge->nextEdge = *itrVectorLower;
            }
            else if ((itrVectorUpper != halfEdgeList.end()) && *halfEdgeToFind == *(*itrVectorUpper))
            {
                (*itrVectorUpper)->adjTriangleIndex = triangle->GetTriangleIndex();
                if (i == 0) halfEdge = *itrVectorUpper;
                if (i == 1) halfEdge->nextEdge = *itrVectorUpper;
                if (i == 2) halfEdge->nextEdge->nextEdge = *itrVectorUpper;
            }
        }
        triangle->SetHalfEdge(halfEdge);
    }
}

vector<TriaMeshSegregated> ComputeTriangularPatchesBFSBased(const TriaMesh& inputTriaMesh)
{
    vector<TriaMeshSegregated> separatedFaces;
    CreateHalfEdgeStructure(inputTriaMesh);
    /*
         Get one triangle and collect the half edge, get other face attached to that half edge, mark the current faces 
         by a flag and put that in a list. Also get the next edge of the half edge in a loop to find all the triangles
         adjacent to the selected traingle, traveral method will be by breadth first traversal method of graph algorithm.

         If the face normals of current and any adjacent face is more than a threashold value (FeatureAngle) exclude
         that face to be included in the list.

         Go to all the adjacent faces and do the same operation as mentioned above, do not visit any face which is already visited . In
         the final if no adjacent face can be found which is not visited then stop the loop. This will give the first face
         and in the given set of tringles check which is not visited and start the same process. In this way if all
         triangles are visited then stop and collect the faces.
    */
    TriangleShared seedTriangle = nullptr;
    do
    {
        seedTriangle = nullptr;
        size_t index = 0;
        // First find a seed triangle from remaining set of trangles which has not been visited
        for (; index < inputTriaMesh.m_meshTriangles.size(); ++index)
        {
            seedTriangle = inputTriaMesh.m_meshTriangles.at(index);
            if (seedTriangle->CheckTriangleVisited()) continue;
            break;
        }
        // If no triange is found break
        if (index == inputTriaMesh.m_meshTriangles.size()) break;

        // Performing a bredth first traversal over the triangle list by using adjacent edges
        // to collect the data for each of the faces which are separated by feature edges
        TriaMeshSegregated meshFaceData;
        meshFaceData.m_meshPoints = inputTriaMesh.m_meshPoints;
        deque<TriangleShared> triangleList;
        triangleList.emplace_back(seedTriangle);

        while (!triangleList.empty())
        {
            seedTriangle = triangleList.front();
            triangleList.pop_front();
            if (seedTriangle->CheckTriangleVisited()) continue;
            const HalfEdgeShared& halfEdgeTraiangle = seedTriangle->GetHalfEdge();
            seedTriangle->SetTriangleVisitedState(true);
            meshFaceData.m_meshTriangles.push_back(seedTriangle);

            HalfEdgeShared halfEdge = halfEdgeTraiangle;
            while (halfEdge)
            {
                TriangleShared adjacentTriangle =
                    inputTriaMesh.m_meshTriangles.at(halfEdge->twinEdge->adjTriangleIndex);
                LineVector triangleNormal = inputTriaMesh.GetTriangleNormal(seedTriangle->GetTriangleIndex());
                LineVector adjTriangleNormal = inputTriaMesh.GetTriangleNormal(adjacentTriangle->GetTriangleIndex());
                halfEdge = halfEdge->nextEdge;
                if (triangleNormal.IncludedAngle(adjTriangleNormal) > FeatureAngle)
                    continue;
                else
                    triangleList.emplace_back(adjacentTriangle);
            }
        }
        meshFaceData.CalculateTriangleNormals();
        separatedFaces.emplace_back(meshFaceData);
    }
    while (seedTriangle);

    // clear visited flag for all triangles
    for_each(
        inputTriaMesh.m_meshTriangles.begin(), inputTriaMesh.m_meshTriangles.end(),
        [](const TriangleShared& tria) { tria->SetTriangleVisitedState(false); });

    return separatedFaces;
}

//depth first implementation
vector<TriaMeshSegregated> ComputeTriangularPatchesDFSBased(const TriaMesh& inputTriaMesh)
{
    vector<TriaMeshSegregated> separatedFaces;
    CreateHalfEdgeStructure(inputTriaMesh);
    /*
         Get one triangle and collect the half edge, get other face attached to that half edge, mark the current faces 
         by a flag and put that in a list. Also get the next edge of the half edge in a loop to find all the triangles
         adjacent to the selected traingle, traveral method will be by depth first traversal method of graph algorithm.

         If the face normals of current and any adjacent face is more than a threashold value (FeatureAngle) exclude
         that face to be included in the list.

         Go to all the adjacent faces and do the same operation as mentioned above, do not visit any face which is already visited . In
         the final if no adjacent face can be found which is not visited then stop the loop. This will give the first face
         and in the given set of tringles check which is not visited and start the same process. In this way if all
         triangles are visited then stop and collect the faces.
    */

    TriangleShared seedTriangle = nullptr;
    do
    {
        seedTriangle = nullptr;
        size_t index = 0;
        // First find a seed triangle from remaining set of trangles which has not been visited
        for (; index < inputTriaMesh.m_meshTriangles.size(); ++index)
        {
            seedTriangle = inputTriaMesh.m_meshTriangles.at(index);
            if (seedTriangle->CheckTriangleVisited()) continue;
            break;
        }
        // If no triange is found break
        if (index == inputTriaMesh.m_meshTriangles.size()) break;

        // Performing a bredth first traversal over the triangle list by using adjacent edges
        // to collect the data for each of the faces which are separated by feature edges
        TriaMeshSegregated meshFaceData;
        meshFaceData.m_meshPoints = inputTriaMesh.m_meshPoints;
        vector<TriangleShared> triangleList;
        triangleList.emplace_back(seedTriangle);

        while (!triangleList.empty())
        {
            seedTriangle = triangleList.back();
            triangleList.pop_back();
            if (seedTriangle->CheckTriangleVisited()) continue;
            const HalfEdgeShared& halfEdgeTraiangle = seedTriangle->GetHalfEdge();
            seedTriangle->SetTriangleVisitedState(true);
            meshFaceData.m_meshTriangles.push_back(seedTriangle);

            HalfEdgeShared halfEdge = halfEdgeTraiangle;
            while (halfEdge)
            {
                TriangleShared adjacentTriangle =
                    inputTriaMesh.m_meshTriangles.at(halfEdge->twinEdge->adjTriangleIndex);
                LineVector triangleNormal = inputTriaMesh.GetTriangleNormal(seedTriangle->GetTriangleIndex());
                LineVector adjTriangleNormal = inputTriaMesh.GetTriangleNormal(adjacentTriangle->GetTriangleIndex());
                halfEdge = halfEdge->nextEdge;
                if (triangleNormal.IncludedAngle(adjTriangleNormal) > FeatureAngle)
                    continue;
                else
                    triangleList.emplace_back(adjacentTriangle);
            }
        }
        meshFaceData.CalculateTriangleNormals(true);
        separatedFaces.emplace_back(meshFaceData);
    }
    while (seedTriangle);

    // clear visited flag for all triangles
    for_each(
        inputTriaMesh.m_meshTriangles.begin(), inputTriaMesh.m_meshTriangles.end(),
        [](const TriangleShared& tria) { tria->SetTriangleVisitedState(false); });

    return separatedFaces;
}

vector<FaceSideEdge> ComputeSurfaceEdges(TriaMeshSegregated& inputTriaMesh)
{
    // Create half edge structure for surface patch
    CreateHalfEdgeStructure(inputTriaMesh);

    for (size_t index = 0; index < inputTriaMesh.m_meshTriangles.size(); ++index)
    {
        HalfEdgeShared halfEdgeTria = inputTriaMesh.m_meshTriangles.at(index)->GetHalfEdge();
        while (halfEdgeTria)
        {
            if (!halfEdgeTria->twinEdge)
            {
                inputTriaMesh.m_boundaryEdges.emplace_back(halfEdgeTria);
            }
            halfEdgeTria = halfEdgeTria->nextEdge;
        }
    }
    //                          Current Edge
    //               |                                     |
    //     Previous Vertex ------ Current Vertex ------- Next Vertex
    // Go through the boundary edges, create a map of vertex number of those edges with adjacent edge
    // indices. Then start from a random vertex, get from the map the edge corresponding to the vertex,
    // from that edge get the adjacent vertex, and from that vertex get the next adjacent edge, continue doing
    // so and collect the edges till the source vertex is reached
    EdgeNodeEdgeOrderMap edgePointEdgeOrderMap;
    HalfEdgeShared edge;
    vector<FaceSideEdge> faceEdges;
    for (size_t index = 0; index < inputTriaMesh.m_boundaryEdges.size(); ++index)
    {
        edge = inputTriaMesh.m_boundaryEdges.at(index);

        edgePointEdgeOrderMap.insert({edge->sourceNodeIndex, static_cast<int>(index)});
        edgePointEdgeOrderMap.insert({edge->targetNodeIndex, static_cast<int>(index)});
    }

    int startNodeIndex = edge->sourceNodeIndex;
    int endNodeIndex = edge->targetNodeIndex;
    HalfEdgeShared currentEdge = edge;
    FaceSideEdge totalSideEdgeList;
    while (edge->sourceNodeIndex != endNodeIndex)
    {
        HalfEdgeShared nextEdge = nullptr;
        auto edgeNodeIndexItr = edgePointEdgeOrderMap.lower_bound(endNodeIndex);
        int edgeIndex = edgeNodeIndexItr->second;
        // As only two nodes are present per edge
        edgeNodeIndexItr++;
        int adjEdgeIndex = edgeNodeIndexItr->second;
        if (*inputTriaMesh.m_boundaryEdges.at(edgeIndex) == *currentEdge)
            nextEdge = inputTriaMesh.m_boundaryEdges.at(adjEdgeIndex);
        else
            nextEdge = inputTriaMesh.m_boundaryEdges.at(edgeIndex);
        if (endNodeIndex == nextEdge->sourceNodeIndex)
        {
            startNodeIndex = nextEdge->sourceNodeIndex;
            endNodeIndex = nextEdge->targetNodeIndex;
        }
        else
        {
            startNodeIndex = nextEdge->targetNodeIndex;
            endNodeIndex = nextEdge->sourceNodeIndex;
        }
        totalSideEdgeList.push_back(currentEdge);
        currentEdge = nextEdge;
    }
    // add the last edge
    totalSideEdgeList.push_back(currentEdge);

    // Angle between index and index +1 edges
    auto angleBetweenAdjacentEdges = [&](const FaceSideEdge& totalSideEdgeList, size_t index)
    {
        size_t indexVal = index % totalSideEdgeList.size();
        size_t nextIndexVal = (index + 1) % totalSideEdgeList.size();
        Point firstEdgeSrcNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(indexVal)->sourceNodeIndex);
        Point firstEdgeTargNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(indexVal)->targetNodeIndex);
        LineVector edgeVect1(firstEdgeSrcNode, firstEdgeTargNode);
        edgeVect1.Normalize();
        Point secondEdgeSrcNode;
        Point secondEdgeTargNode;
        if (totalSideEdgeList.at(indexVal)->targetNodeIndex == totalSideEdgeList.at(nextIndexVal)->sourceNodeIndex)
        {
            secondEdgeSrcNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(nextIndexVal)->sourceNodeIndex);
            secondEdgeTargNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(nextIndexVal)->targetNodeIndex);
        }
        else
        {
            secondEdgeSrcNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(nextIndexVal)->targetNodeIndex);
            secondEdgeTargNode = inputTriaMesh.m_meshPoints->at(totalSideEdgeList.at(nextIndexVal)->sourceNodeIndex);
        }
        LineVector edgeVect2(secondEdgeSrcNode, secondEdgeTargNode);
        edgeVect2.Normalize();
        return edgeVect1.IncludedAngle(edgeVect2);
    };

    FaceSideEdge firstSurfaceEdge;
    size_t i = 0;
    for (; i < totalSideEdgeList.size(); ++i)
    {
        size_t index = i % totalSideEdgeList.size();
        firstSurfaceEdge.push_back(totalSideEdgeList.at(index));
        if (angleBetweenAdjacentEdges(totalSideEdgeList, index) > FeatureAngle) break;
    }

    i++;
    vector<FaceSideEdge> sideEdges;
    FaceSideEdge sideEdge;
    for (; i < totalSideEdgeList.size(); ++i)
    {
        size_t index = i % totalSideEdgeList.size();
        sideEdge.push_back(totalSideEdgeList.at(index));
        if (angleBetweenAdjacentEdges(totalSideEdgeList, index) > FeatureAngle)
        {
            faceEdges.emplace_back(sideEdge);
            sideEdge.clear();
        }
    }
    for (const HalfEdgeShared& edge : firstSurfaceEdge)
        sideEdge.emplace_back(edge);

    faceEdges.emplace_back(sideEdge);
    return faceEdges;
}

ParametrizedFaceShared CreateParametrizedFaceFromSideEdges(
    const TriaMeshSegregated& inputTriaMesh,
    const vector<FaceSideEdge>& sideEdges)
{
    /*
        ParametrizedEdge is edge of a face with unique list of vertices ordered from start to end
        We need to convert FaceSideEdge structure to ParametrizedEdge structure. 
        FaceSideEdge is combination of ordered (start-to-end) half edges.
        So loop over those half edges and find out the unique vertices from start to end for
        the edges and store in the ParametrizedFace structure. 
        Also sort the edge point indices, so those will be used to find out the unique parametrized side
        edges from group of duplicate side edges, from group of side faces 
     */
    vector<ParametrizedEdgeShared> parametrizedSideEdges;
    for (size_t i = 0; i < sideEdges.size(); ++i)
    {
        vector<PointShared> edgePoints;
        vector<size_t> edgePointIndices;
        FaceSideEdge sideEdge = sideEdges.at(i);
        size_t lastEdgeIndex = sideEdge.size() - 1;

        for (size_t j = 0; j < sideEdge.size(); ++j)
        {
            if (j == 0)
            {
                edgePoints.push_back(
                    make_shared<Point>(inputTriaMesh.m_meshPoints->at(sideEdge.at(j)->sourceNodeIndex)));
                edgePointIndices.push_back(sideEdge.at(j)->sourceNodeIndex);
                edgePoints.push_back(
                    make_shared<Point>(inputTriaMesh.m_meshPoints->at(sideEdge.at(j)->targetNodeIndex)));
                edgePointIndices.push_back(sideEdge.at(j)->targetNodeIndex);
            }
            else if (
                sideEdge.at(j - 1)->targetNodeIndex == sideEdge.at(j)->sourceNodeIndex ||
                sideEdge.at(j - 1)->sourceNodeIndex == sideEdge.at(j)->sourceNodeIndex)
            {
                edgePoints.push_back(
                    make_shared<Point>(inputTriaMesh.m_meshPoints->at(sideEdge.at(j)->targetNodeIndex)));
                edgePointIndices.push_back(sideEdge.at(j)->targetNodeIndex);
            }
            else if (
                sideEdge.at(j - 1)->targetNodeIndex == sideEdge.at(j)->targetNodeIndex ||
                sideEdge.at(j - 1)->sourceNodeIndex == sideEdge.at(j)->targetNodeIndex)
            {
                edgePoints.push_back(
                    make_shared<Point>(inputTriaMesh.m_meshPoints->at(sideEdge.at(j)->sourceNodeIndex)));
                edgePointIndices.push_back(sideEdge.at(j)->sourceNodeIndex);
            }
            else
            {
                assert("Index error");
            }
        }
        ParametrizedEdgeShared sideEdgeParametrized = make_shared<ParametrizedEdge>(std::move(edgePoints));
        sort(edgePointIndices.begin(), edgePointIndices.end(), less<int>());
        sideEdgeParametrized->SetEdgePointIndices(edgePointIndices);
        parametrizedSideEdges.emplace_back(sideEdgeParametrized);
    }
    return make_shared<ParametrizedFace>(inputTriaMesh.GetCentroid(), parametrizedSideEdges);
}

void UpdateParametrizedFaceWithUniqueParametrizedEdges(vector<ParametrizedFaceShared>& parametrizedSideFaces)
{
    /*
       From a set of parametrized face edges find out the unique edges and update it in the respective
       parametrized faces. 

       -------------
       |     |     |
       |     |     |
       -------------

       If two adjacent faces have common side edge, then remove the duplicate one during this process
       and update the unique parametrized edges in each parametrized faces.
       Loop through all the parametrized faces, get list of all parametrized edges. Sort those edge list
       by those respective indices and remove and erase the duplicate edges.
       Now loop through the face edges and replace the duplicate edges with the unique edges for respective 
       faces
    */
    vector<ParametrizedEdgeShared> paramEdgesList;
    for (const ParametrizedFaceShared& sharedParamFace : parametrizedSideFaces)
    {
        for (const ParametrizedEdgeShared& sharedParamEdge : sharedParamFace->GetParametrizedEdges())
        {
            paramEdgesList.push_back(sharedParamEdge);
        }
    }

    sort(
        paramEdgesList.begin(), paramEdgesList.end(),
        [](const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2) { return *edge1 < *edge2; });

    paramEdgesList.erase(
        unique(
            paramEdgesList.begin(), paramEdgesList.end(),
            [](const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2) { return *edge1 == *edge2; }),
        paramEdgesList.end());

    for (const ParametrizedFaceShared& sharedParamFace : parametrizedSideFaces)
    {
        const vector<ParametrizedEdgeShared>& edgeList = sharedParamFace->GetParametrizedEdges();
        vector<ParametrizedEdgeShared> replacedEdges;
        for (size_t i = 0; i < edgeList.size(); ++i)
        {
            // Find the duplicate edge matches the specification of one of the edge in the unique edge list
            auto itrVector = lower_bound(
                paramEdgesList.begin(), paramEdgesList.end(), edgeList.at(i),
                [](const ParametrizedEdgeShared& edge1, const ParametrizedEdgeShared& edge2)
                { return *edge1 < *edge2; });

            // check that value has been found
            assert(itrVector != paramEdgesList.end());
            replacedEdges.push_back(*itrVector);
        }
        sharedParamFace->SetParametrizedEdges(replacedEdges);
    }
}
/*

     * plot3d: (output)
         * No. of blocks of the grid (In this case, it is 1)
         * Number of nodes in i, j and k directions (Nx, Ny and Nz)
	 * Coordinates of the nodes of the grid using nested for loops

	 1
	 <Nx> <Ny> <Nz>
	 for i in [0, Nx]:
	     for j in [0, Ny]:
	         for k in [0, Nz]:
		         Xn Yn Zn

 */

bool OutputVolumeMeshData(const vector<vector<vector<PointShared>>>& volumeMesh, const string& outputFileName)
{
    ofstream outFile(outputFileName, ios::out);

    // Number of blocks
    constexpr int numBlocks = 1;
    outFile << numBlocks << endl;
    size_t xNumPoints = volumeMesh.size();
    size_t yNumPoints = volumeMesh[0].size();
    size_t zNumPoints = volumeMesh[0][0].size();

    outFile << xNumPoints << " " << yNumPoints << " " << zNumPoints << endl;

    // Print out the points
    for (size_t i = 0; i < xNumPoints; ++i)
    {
        for (size_t j = 0; j < yNumPoints; ++j)
        {
            for (size_t k = 0; k < xNumPoints; ++k)
            {
                PointShared volPt = volumeMesh[i][j][k];
                outFile << volPt->GetXCoord() << " " << volPt->GetYCoord() << " " << volPt->GetZCoord() << endl;
            }
        }
    }
    outFile << endl;
    outFile.close();

    return true;
}

bool OutputLayerMeshData(const vector<vector<PointShared>>& inputTriaMesh, const string& outputFileName)
{

    /*
            --------
           | \     |\
           ---------
        Y  \   \    \ \
               --------^
             \ |      \| Z
              ---------       ->X
    */
    //Output layer mesh for each Z direction value 
    ofstream outFile(outputFileName, ios::out);

    outFile << "Layer STL generated as Output" << endl;

    int index = 0;
    for (size_t i = 0; i < inputTriaMesh.size() - 1; ++i)
    {
        for (size_t j = 0; j < inputTriaMesh[i].size() - 1; ++j)
        {
            index++;
            Point triaPt[3];
            triaPt[0] = *inputTriaMesh[i][j];
            triaPt[1] = *inputTriaMesh[i + 1][j];
            triaPt[2] = *inputTriaMesh[i + 1][j + 1];
            LineVector facetNormal = LineVector(triaPt[0], triaPt[1]).CrossProduct(LineVector(triaPt[0], triaPt[2]));
            facetNormal.Normalize();
            facetNormal.Flip();
            outFile << "\tfacet normal " << facetNormal[0] << " " << facetNormal[1] << " " << facetNormal[2] << endl;
            outFile << "\t outer loop" << endl;
            for (int k = 0; k < 3; ++k)
            {
                outFile << "\t  vertex " << triaPt[k].GetXCoord() << " " << triaPt[k].GetYCoord() << " "
                        << triaPt[k].GetZCoord() << endl;
            }
            outFile << "\t endloop" << endl;
            outFile << "\tendfacet" << endl;

            triaPt[0] = *inputTriaMesh[i][j];
            triaPt[1] = *inputTriaMesh[i + 1][j + 1];
            triaPt[2] = *inputTriaMesh[i][j + 1];
            facetNormal = LineVector(triaPt[0], triaPt[1]).CrossProduct(LineVector(triaPt[0], triaPt[2]));
            facetNormal.Normalize();
            facetNormal.Flip();
            outFile << "\tfacet normal " << facetNormal[0] << " " << facetNormal[1] << " " << facetNormal[2] << endl;
            outFile << "\t outer loop" << endl;
            for (int k = 0; k < 3; ++k)
            {
                outFile << "\t  vertex " << triaPt[k].GetXCoord() << " " << triaPt[k].GetYCoord() << " "
                        << triaPt[k].GetZCoord() << endl;
            }
            outFile << "\t endloop" << endl;
            outFile << "\tendfacet" << endl;
        }
    }

    outFile << "endsolid vcg" << endl;

    outFile.close();

    return true;
}
